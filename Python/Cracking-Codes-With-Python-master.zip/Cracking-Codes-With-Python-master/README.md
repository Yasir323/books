# Cracking-Codes-With-Python
For ethical practice

Files in this repository can be used to try to crack different kinds of codes and ciphers. 

Most of these are covered more in depth in the book __Cracking Codes With Python__ by Al Sweigart.
